<script>
(function($) {
"use strict";
        var gallery = new SimpleLightbox('.gallery a', {});

})(jQuery); 
</script>